import{z as a}from"./yo6EL1wl.js";a();
